﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Enums
{
	public enum AnimationEnum
	{
		//temporary names since no animations have been made yet
		Idle0,
		Idle1
	}
}